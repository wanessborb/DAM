import { StatusBar } from 'react-native'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import TelaHome from './src/screens/home'
import TelaUser from './src/screens/user'
import TelaLogin from './src/screens/login'
import TelaAbout from './src/screens/about'
import { NavigationContainer } from '@react-navigation/native'


const Stack = createNativeStackNavigator()

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Home" component={TelaHome}/>
        <Stack.Screen name="User" component={TelaUser}/>
        <Stack.Screen name="Login" component={TelaLogin}/>
        <Stack.Screen name="About" component={TelaAbout}/>
      </Stack.Navigator>
      <StatusBar style="auto" />
    </NavigationContainer>
  )
}