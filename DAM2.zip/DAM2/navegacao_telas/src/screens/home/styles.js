import { StyleSheet } from "react-native"
import { colors } from "../../styles"

const styles = StyleSheet.create({
    text: {
        fontSize: 15,
        color:colors.purple
    },
    grey: {
        backgroundColor: colors.grey,
        justifyContent: 'center',
    }
})

export default styles