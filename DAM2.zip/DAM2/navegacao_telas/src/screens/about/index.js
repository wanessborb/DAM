import React from 'react'
import { Text, View} from 'react-native'
import styles from './styles.js'

const TelaAbout = () => {
 
    const namecomplete = "Wanessa Borba"

    return (
        <View style={styles.grey}>
            <Text style={styles.textnegrite}> About </Text>
            <Text style={styles.text}> Developed by {namecomplete} </Text>
            <Text style={styles.textnegrite}> Version </Text>
            <Text style={styles.text}> FistApp Version 1.0 </Text>
        </View>
        )

}


export default TelaAbout