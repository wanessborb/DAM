import React from 'react'
import { Text,View} from 'react-native'
import styles from './styles.js'


const TelaUser = () => {
 
    const namecomplete = "Wanessa Borba"
    const age = "22"
    const email = "wanessa.borba@estudante.ifgoiano.edu.br"

    return (
        <View style={styles.grey}>
            <Text style={styles.textnegrite}> Name </Text>
            <Text style={styles.text}> {namecomplete} </Text>
            <Text style={styles.textnegrite}> Age </Text>
            <Text style={styles.text}> {age} </Text>
            <Text style={styles.textnegrite}> Email </Text>
            <Text style={styles.text}> {email} </Text>
        </View>
        )

}


export default TelaUser