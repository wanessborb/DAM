import React, { useState } from 'react'
import { View, TextInput, Button} from 'react-native'
import styles from './styles.js'


const TelaLogin = (props) => {
    console.log(props)
    const navigation = props.navigation
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');

    return (
        <View style={styles.container}>
        <TextInput
            placeholder="Username"
            value={username}
            onChangeText={setUsername}
            style={styles.input}
        />
        <TextInput
            placeholder="Password"
            value={password}
            onChangeText={setPassword}
            style={styles.input}
            secureTextEntry
        />
        <Button       
                onPress={() => {
                    console.log('Home')
                    navigation.navigate('Home')
                }}
                title="Login" />
        </View>
    );
    };


export default TelaLogin;