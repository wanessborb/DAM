const colors = {
    header: '#111111',
    primary: '#069',
    warning: '#FF3333',
    text: '#333333',
    grey: '#363636',
    purple: '#DA70D6',
    blue: '#0000CD'
  }
  
  export default colors