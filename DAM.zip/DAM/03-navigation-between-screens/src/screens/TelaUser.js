import React from 'react'
import { Text, StyleSheet, View} from 'react-native'


const TelaAbout = () => {
 
    const namecomplete = "Wanessa Borba"
    const age = "22"
    const email = "wanessa.borba@gmail.com"

    return (
        <View>
            <Text style={styles.textnegrite}> Name </Text>
            <Text style={styles.text}> {namecomplete} </Text>
            <Text style={styles.textnegrite}> Age </Text>
            <Text style={styles.text}> {age} </Text>
            <Text style={styles.textnegrite}> Email </Text>
            <Text style={styles.text}> {email} </Text>
        </View>
        )

}

const styles = StyleSheet.create({
    text: {
        fontSize: 15
    },
    textnegrite: {
        fontSize: 15,
        fontWeight: 'bold',
    }
})

export default TelaAbout